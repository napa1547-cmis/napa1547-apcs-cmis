import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Interactives extends Actor
   {
    World world;
    
    public void act()
       {
        fall(); 
        FireFall();
       }
    
    public void fall()
       { 
        setLocation(getX(),getY()+3);
        Actor mobil = getOneIntersectingObject(Pig.class);
        world = getWorld();
        if (isAtEdge()) 
           {
            getWorld().addObject(new Apple(), Greenfoot.getRandomNumber(getWorld().getWidth()),
            Greenfoot.getRandomNumber(getWorld().getHeight()-490));
            world.removeObject(this);
           }
       }
       
    public void FireFall()
       { 
        setLocation(getX(),getY()+3);
        Actor mobil = getOneIntersectingObject(Pig.class);
        world = getWorld();
        if (isAtEdge()) 
           {
            getWorld().addObject(new Fire(), Greenfoot.getRandomNumber(getWorld().getWidth()),
            Greenfoot.getRandomNumber(getWorld().getHeight()-490));
            world.removeObject(this);
           }
       }
       
    public void eat()
       {
        Actor Apple = getOneIntersectingObject(Pig.class);    
        
        if(Apple != null)
           {
            getWorld().removeObject(this);
            getWorld().addObject(new Apple(), Greenfoot.getRandomNumber(getWorld().getWidth()),
            Greenfoot.getRandomNumber(getWorld().getHeight()-490));
           }
           
       }
       
    
   }
